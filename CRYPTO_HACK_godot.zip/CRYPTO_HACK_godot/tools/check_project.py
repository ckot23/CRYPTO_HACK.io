#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Проверка проекта CRYPTO_HACK на ошибки, которые Godot сообщает только при запуске.

Зачем: сам движок в этой среде недоступен, а `gdparse` видит только синтаксис.
Скрипт ловит то, на что Godot ругается «Parser Error» / «Invalid access»:

  1. одно имя объявлено дважды (signal + func, две var и т. п.)
  2. член перекрывает встроенный член базового класса (например, var size в Control)
  3. сигнатура переопределённого виртуального метода не совпадает с родительской
  4. локальная переменная объявлена в одном блоке дважды
  5. static func обращается к нестатическому члену класса
  6. путь res://… в коде/сценах указывает на несуществующий файл

Запуск (Python 3.8+, никаких зависимостей):
    python3 tools/check_project.py

Код возврата: 0 — чисто, 1 — найдены проблемы.
"""

import json
import os
import re
import sys

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
API_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "godot_api.json")

DECL = re.compile(
    r"^(signal|var|const|enum|func|static\s+var|static\s+func)\s+([A-Za-z_]\w*)\s*(\([^)]*\))?",
    re.M,
)

BUILTIN = {
    "self", "true", "false", "null", "if", "elif", "else", "for", "while", "match",
    "return", "var", "const", "func", "static", "signal", "enum", "class_name",
    "extends", "await", "yield", "pass", "break", "continue", "not", "and", "or",
    "in", "is", "as", "void", "super", "preload", "load", "assert", "breakpoint",
}


def load_api():
    if not os.path.exists(API_PATH):
        return {}
    with open(API_PATH, encoding="utf-8") as fh:
        return json.load(fh)


def class_chain(api, cls):
    out, seen = [], set()
    while cls and cls in api and cls not in seen:
        seen.add(cls)
        out.append(cls)
        cls = api[cls].get("parent")
    return out


def check_file(path, api):
    """Возвращает список найденных проблем для одного .gd файла."""
    problems = []
    rel = os.path.relpath(path, ROOT)
    with open(path, encoding="utf-8") as fh:
        src = fh.read()

    # ---------- 1. дубли имён ----------
    declared = {}
    for m in DECL.finditer(src):
        kind = m.group(1).split()[-1]
        declared.setdefault(m.group(2), []).append((kind, m.group(3) or ""))

    for name, occ in declared.items():
        if len(occ) > 1:
            kinds = [k for k, _ in occ]
            problems.append(
                f'{rel}: имя "{name}" объявлено {len(occ)} раза ({", ".join(kinds)}) — '
                f"Godot не разрешит сигнал и функцию с одним именем"
            )

    base = None
    bm = re.search(r"^extends\s+([\w\.]+)", src, re.M)
    if bm:
        base = bm.group(1)

    # ---------- 2. перекрытие членов базового класса ----------
    if base:
        for cls in class_chain(api, base):
            for name in declared:
                if name.startswith("_"):
                    continue
                if name in api[cls]["members"]:
                    problems.append(
                        f'{rel}: "{name}" перекрывает встроенный член класса {cls} '
                        f"(базовый класс {base}) — переименуй"
                    )

    # ---------- 3. сигнатуры виртуальных методов ----------
    if base:
        for name, occ in declared.items():
            if not name.startswith("_"):
                continue
            for kind, args in occ:
                if kind != "func":
                    continue
                for cls in class_chain(api, base):
                    if name not in api[cls].get("virtuals", {}):
                        continue
                    want = api[cls]["virtuals"][name]["params"]
                    got = [p.split(":")[-1].strip() for p in args.strip("()").split(",") if p.strip()]
                    if len(got) != len(want) or any(
                        g and w and g != w for g, w in zip(got, want)
                    ):
                        problems.append(
                            f"{rel}: {name}() из {cls} ждёт аргументы {want or '[]'}, у нас {got or '[]'}"
                        )
                    break

    # ---------- 4. дубли локальных переменных ----------
    for fm in re.finditer(
        r"^\t*(?:static\s+)?func\s+(\w+)[^\n]*:\n((?:\t[^\n]*\n|\n)*)", src, re.M
    ):
        stack = [(0, set())]
        for raw in fm.group(2).split("\n"):
            if not raw.strip():
                continue
            indent = len(raw) - len(raw.lstrip("\t"))
            while len(stack) > 1 and indent <= stack[-1][0]:
                stack.pop()
            local = re.match(r"var\s+([A-Za-z_]\w*)", raw.strip())
            if local:
                name = local.group(1)
                if name in stack[-1][1]:
                    problems.append(
                        f'{rel}: в функции {fm.group(1)}() переменная "{name}" объявлена дважды в одном блоке'
                    )
                stack[-1][1].add(name)
            elif raw.strip().startswith(("if", "for", "while", "match", "else", "elif")):
                stack.append((indent, set()))

    # ---------- 5. static func и нестатические члены ----------
    instance = set(re.findall(r"^(?:var|func)\s+([A-Za-z_]\w*)", src, re.M))
    if instance:
        for fm in re.finditer(
            r"^static func\s+(\w+)\s*\(([^)]*)\)[^\n]*:\n((?:\t[^\n]*\n|\n)*)", src, re.M
        ):
            fname, params, body = fm.group(1), fm.group(2), fm.group(3)
            known = set(re.findall(r"([A-Za-z_]\w*)", params))
            known |= set(re.findall(r"^\t*var\s+([A-Za-z_]\w*)", body, re.M))
            known |= set(re.findall(r"\bfor\s+([A-Za-z_]\w*)\s+in\b", body))
            clean = re.sub(r'"[^"]*"', '""', body)
            clean = re.sub(r"'[^']*'", "''", clean)
            clean = re.sub(r"#.*", "", clean)
            clean = re.sub(r"\.\s*[A-Za-z_]\w*", "", clean)  # обращения через точку
            for ident in set(re.findall(r"(?<![\w$])([A-Za-z_]\w*)", clean)):
                if ident in instance and ident not in known and ident not in BUILTIN:
                    problems.append(
                        f'{rel}: static func {fname}() обращается к нестатическому члену "{ident}"'
                    )
    return problems


def check_res_paths():
    problems = []
    pattern = re.compile(r"res://([A-Za-z0-9_./-]+)")
    for folder, _, files in os.walk(ROOT):
        if os.sep + ".godot" in folder:
            continue
        for fname in files:
            if not fname.endswith((".gd", ".tscn", ".tres", ".godot")):
                continue
            path = os.path.join(folder, fname)
            with open(path, encoding="utf-8", errors="replace") as fh:
                text = fh.read()
            for m in pattern.finditer(text):
                target = os.path.join(ROOT, m.group(1).rstrip("."))
                if not os.path.exists(target):
                    problems.append(
                        f"{os.path.relpath(path, ROOT)}: путь {m.group(0)} никуда не ведёт"
                    )
    return problems


def main():
    api = load_api()
    if not api:
        print("ВНИМАНИЕ: не найден tools/godot_api.json — проверки 2 и 3 пропущены")
    scripts = []
    for folder, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in (".godot", ".git", "build", "export")]
        scripts += [os.path.join(folder, f) for f in files if f.endswith(".gd")]
    scripts.sort()

    problems = []
    for path in scripts:
        problems += check_file(path, api)
    problems += check_res_paths()

    print(f"Проверено файлов .gd: {len(scripts)}")
    if not problems:
        print("Проблем не найдено — можно запускать в Godot (F5).")
        return 0
    print(f"Найдено проблем: {len(problems)}\n")
    for p in problems:
        print("  •", p)
    return 1


if __name__ == "__main__":
    sys.exit(main())
