#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Проверка проекта CRYPTO_HACK на ошибки, которые Godot сообщает при загрузке
скриптов (Parser Error) — те, что не видит проверка синтаксиса gdparse.

Нужен только Python 3.8+ (зависимостей нет).

    python3 tools/check_project.py

Проверки:
  1. var X := <выражение типа Variant>     -> "Cannot infer the type of X"
  2. имя объявлено дважды в одном классе   -> сигнал + функция с одним именем
  3. член перекрывает встроенный член базового класса (Control.size и т. п.)
  4. сигнатура виртуального метода не совпадает с родительской (_draw, _process…)
  5. локальная переменная объявлена дважды в одном блоке
  6. static func обращается к нестатическому члену
  7. неизвестный тип в аннотации (: Foo, -> Foo, extends Foo)
  8. вызов нестатического метода через имя класса
  9. дубли class_name, значения enum и пути res://
"""
import glob
import json
import os
import re
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
ROOT = os.path.dirname(HERE)

with open(os.path.join(HERE, 'godot_api.json'), encoding='utf-8') as fh:
    API = json.load(fh)

GLOB = API.get('@GlobalScope', {})
GLOB_METHODS = {k: v['return'] for k, v in GLOB.get('methods', {}).items()}
NUMERIC = {'int', 'float'}
BUILTIN_TYPES = {'void', 'Variant', 'int', 'float', 'bool', 'String', 'StringName', 'NodePath',
                 'Nil', 'RID', 'Signal', 'Callable', 'Object', 'Array', 'Dictionary'}
KEYWORDS = {
    'if', 'elif', 'else', 'for', 'while', 'match', 'return', 'var', 'const', 'func', 'static',
    'signal', 'enum', 'class_name', 'extends', 'await', 'yield', 'pass', 'break', 'continue',
    'not', 'and', 'or', 'in', 'is', 'as', 'void', 'self', 'super', 'true', 'false', 'null',
    'preload', 'load', 'assert', 'breakpoint', 'print', 'printerr', 'push_error', 'push_warning',
}
# методы контейнеров, которые возвращают Variant (Element) — по документации Godot
VARIANT_RETURNERS = {
    'pop_back', 'pop_front', 'pop_at', 'front', 'back', 'max', 'min', 'pick_random', 'reduce',
    'get', 'pop', 'find_key', 'sample', 'call', 'callv', 'call_deferred', 'rpc', 'rpc_id',
    'parse_string', 'parse', 'get_meta', 'weakref', 'callable',
}


# ============================================================= разбор исходников
def balance(text):
    depth, instr, i = 0, None, 0
    while i < len(text):
        c = text[i]
        if instr:
            if c == '\\':
                i += 2
                continue
            if c == instr:
                instr = None
        elif c in '"\'':
            instr = c
        elif c == '#':
            break
        elif c in '([{':
            depth += 1
        elif c in ')]}':
            depth -= 1
        i += 1
    return depth


def uncomment(line):
    out, i, instr = [], 0, None
    while i < len(line):
        ch = line[i]
        if instr:
            if ch == '\\':
                out.append(line[i:i + 2])
                i += 2
                continue
            if ch == instr:
                instr = None
            out.append(ch)
        elif ch in '"\'':
            instr = ch
            out.append(ch)
        elif ch == '#':
            break
        else:
            out.append(ch)
        i += 1
    return ''.join(out)


def top_split(expr, sep):
    parts, depth, cur, instr, i = [], 0, [], None, 0
    while i < len(expr):
        c = expr[i]
        if instr:
            if c == '\\':
                cur.append(expr[i:i + 2])
                i += 2
                continue
            if c == instr:
                instr = None
            cur.append(c)
        elif c in '"\'':
            instr = c
            cur.append(c)
        elif c in '([{':
            depth += 1
            cur.append(c)
        elif c in ')]}':
            depth -= 1
            cur.append(c)
        elif depth == 0 and expr.startswith(sep, i):
            parts.append(''.join(cur))
            cur = []
            i += len(sep)
            continue
        else:
            cur.append(c)
        i += 1
    parts.append(''.join(cur))
    return parts


def find_top(expr, seps):
    depth, instr, i = 0, None, 0
    while i < len(expr):
        c = expr[i]
        if instr:
            if c == '\\':
                i += 2
                continue
            if c == instr:
                instr = None
        elif c in '"\'':
            instr = c
        elif c in '([{':
            depth += 1
        elif c in ')]}':
            depth -= 1
        elif depth == 0:
            for s in seps:
                if expr.startswith(s, i):
                    if s[0].isalpha():
                        before = expr[i - 1] if i else ' '
                        after = expr[i + len(s)] if i + len(s) < len(expr) else ' '
                        if before.isalnum() or before == '_' or after.isalnum() or after == '_':
                            continue
                    return i
        i += 1
    return -1


def const_type(value):
    """Тип встроенной константы по её значению из документации (Vector2.ZERO -> Vector2)."""
    v = str(value or '').strip()
    if re.match(r'^-?\d+$', v):
        return 'int'
    if re.match(r'^-?\d*\.\d+', v) or re.match(r'^-?\d+\.\d*', v):
        return 'float'
    if v in ('true', 'false'):
        return 'bool'
    if v.startswith('"') or v.startswith("'"):
        return 'String'
    for t in ('Vector2i', 'Vector2', 'Vector3i', 'Vector3', 'Vector4', 'Rect2i', 'Rect2',
              'Transform2D', 'Transform3D', 'Color', 'Quaternion', 'Plane', 'Basis', 'AABB',
              'Projection', 'NodePath', 'StringName'):
        if v.startswith(t + '('):
            return t
    if v.startswith('&"'):
        return 'StringName'
    if v.startswith('^"'):
        return 'NodePath'
    return 'Variant'


def literal_type(e):
    e = e.strip()
    if not e:
        return None
    if e[0] in '"\'':
        return 'String'
    if e.startswith('['):
        # В GDScript литерал массива НЕтипизированный: const A := [1.0] -> Array (не Array[float]),
        # поэтому A[0] имеет тип Variant и var x := A[0] не выведется.
        return 'Array'
    if re.match(r'^Array\[([\w\.]+)\]\(', e):
        return 'Array[%s]' % re.match(r'^Array\[([\w\.]+)\]\(', e).group(1)
    if re.match(r'^Array\(', e):
        return 'Array'
    if e.startswith('{'):
        return 'Dictionary'
    if re.match(r'^-?\d+$', e):
        return 'int'
    if re.match(r'^-?(\d+\.\d*|\.\d+)([eE][-+]?\d+)?$', e) or re.match(r'^\d+\.\d*$', e):
        return 'float'
    if e in ('true', 'false'):
        return 'bool'
    if e == 'null':
        return 'Nil'
    if e.startswith('Color(') or e.startswith('Color8('):
        return 'Color'
    if e.startswith('Vector2i('):
        return 'Vector2i'
    if e.startswith('Vector2('):
        return 'Vector2'
    if e.startswith('Rect2('):
        return 'Rect2'
    if e.startswith(('NodePath(', '^"')):
        return 'NodePath'
    if e.startswith(('StringName(', '&"')):
        return 'StringName'
    if e.startswith('PackedStringArray('):
        return 'PackedStringArray'
    if e.startswith('PackedByteArray('):
        return 'PackedByteArray'
    return None


class Func:
    def __init__(self, name, params, ret, static, body, line):
        self.name, self.params, self.ret = name, params, ret
        self.static, self.body, self.line = static, body, line


class Klass:
    def __init__(self, path, rel):
        self.path, self.rel = path, rel
        self.name = None
        self.base = None
        self.members = {}
        self.consts = {}
        self.enums = {}
        self.funcs = {}
        self.static_vars = set()
        self.member_inits = {}
        self.signals = set()
        self.src = ''
        self.lines = []

    def member_type(self, name):
        if name in self.consts:
            return self.consts[name]
        if name in self.members:
            return self.members[name]
        if name in self.enums:
            return 'ENUM'
        if name in self.funcs:
            return 'Callable'
        if name in self.signals:
            return 'Signal'
        return None


def parse_params(text):
    out = []
    for raw in top_split(text, ','):
        raw = raw.strip()
        if not raw:
            continue
        default = '=' in raw
        if default:
            raw = raw.split('=', 1)[0].strip()
        if ':' in raw:
            nm, tp = raw.split(':', 1)
            out.append((nm.strip(), tp.strip(), default))
        else:
            out.append((raw, 'Variant', default))
    return out


def merge_lines(src):
    raw = src.split('\n')
    out, i = [], 0
    while i < len(raw):
        text = uncomment(raw[i])
        start = i + 1
        depth = balance(text)
        while depth > 0 and i + 1 < len(raw):
            i += 1
            nxt = uncomment(raw[i])
            text += '\n' + nxt
            depth += balance(nxt)
        out.append((start, text))
        i += 1
    return out


def parse_project():
    classes = {}
    files = []
    for path in sorted(glob.glob(os.path.join(ROOT, 'scripts/**/*.gd'), recursive=True)):
        rel = os.path.relpath(path, ROOT).replace(os.sep, '/')
        src = open(path, encoding='utf-8').read()
        k = Klass(path, rel)
        k.src = src
        m = re.search(r'^class_name\s+(\w+)', src, re.M)
        if m:
            k.name = m.group(1)
        m = re.search(r'^extends\s+([\w\.]+)', src, re.M)
        if m:
            k.base = m.group(1)
        k.lines = merge_lines(src)
        for idx, (start, line) in enumerate(k.lines):
            if line.startswith(('\t', ' ')) or line.strip().startswith('#'):
                continue
            s = line.strip()
            m = re.match(r'signal\s+(\w+)', s)
            if m:
                k.signals.add(m.group(1))
                continue
            m = re.match(r'enum\s+(\w+)?\s*\{(.*)\}', s, re.S)
            if m:
                k.enums[m.group(1) or ('enum_%d' % idx)] = [
                    v.strip().split('=')[0].strip() for v in top_split(m.group(2), ',') if v.strip()]
                continue
            m = re.match(r'(static\s+)?func\s+(\w+)\s*\((.*?)\)\s*(?:->\s*([\w\.\[\]]+))?\s*:', s, re.S)
            if m:
                body = []
                j = idx + 1
                while j < len(k.lines):
                    nxt = k.lines[j][1]
                    if nxt.strip() and not nxt.startswith(('\t', ' ')):
                        break
                    body.append(nxt)
                    j += 1
                k.funcs[m.group(2)] = Func(m.group(2), parse_params(m.group(3)),
                                           m.group(4) or 'Variant', bool(m.group(1)),
                                           '\n'.join(body), start)
                continue
            m = re.match(r'(static\s+)?(?:@\w+(?:\([^)]*\))?\s*)*(var|const)\s+(\w+)\s*'
                         r'(?::\s*([\w\.\[\]]+))?\s*(:=|=)?\s*(.*)$', s)
            if m:
                static, kind, name, tpe, op, rhs = (m.group(1), m.group(2), m.group(3),
                                                    m.group(4), m.group(5), m.group(6))
                if kind == 'const':
                    k.consts[name] = tpe or literal_type(rhs) or 'Variant'
                else:
                    if static:
                        k.static_vars.add(name)
                    if tpe:
                        k.members[name] = tpe
                    elif op == ':=':
                        k.members[name] = None      # вычислим после разбора всех классов
                        k.member_inits[name] = rhs
                    else:
                        k.members[name] = 'Variant'  # var x = 5 -> именно Variant
                continue
        classes[rel] = k
        files.append(k)
    return classes, files


# автозагрузки из project.godot
def autoloads(classes):
    out = {}
    path = os.path.join(ROOT, 'project.godot')
    if os.path.exists(path):
        for m in re.finditer(r'^(\w+)="\*?res://([^"]+)"', open(path, encoding='utf-8').read(), re.M):
            name, script = m.group(1), m.group(2)
            for rel, k in classes.items():
                if rel.endswith(script):
                    out[name] = k
    return out


# ============================================================= вывод типов
UNKNOWN = 'UNKNOWN'


class Resolver:
    def __init__(self, classes, autos):
        self.by_name = {k.name: k for k in classes.values() if k.name}
        self.classes, self.autos = classes, autos

    def chain(self, cls):
        out, seen = [], set()
        while cls and cls not in seen:
            seen.add(cls)
            out.append(cls)
            k = self.by_name.get(cls)
            cls = k.base if k else API.get(cls, {}).get('parent')
        return out

    def func_of(self, cls, name):
        for c in self.chain(cls):
            k = self.by_name.get(c)
            if k and name in k.funcs:
                return k.funcs[name]
            info = API.get(c)
            if info and name in info.get('methods', {}):
                m = info['methods'][name]
                return Func(name, [(n, t, True) for n, t in zip(m['params'], m['params'])],
                            m['return'], m['static'], '', 0)
        return None

    def member_of(self, cls, name):
        for c in self.chain(cls):
            k = self.by_name.get(c)
            if k:
                t = k.member_type(name)
                if t:
                    return t
            info = API.get(c)
            if info:
                if name in info.get('members', {}):
                    return info['members'][name]
                if name in info.get('constants', {}):
                    return const_type(info['constants'][name])
                if name in info.get('signals', {}):
                    return 'Signal'
                if any(name in e for e in info.get('enums', {}).values()):
                    return 'int'
        return None

    def is_class(self, name):
        return name in self.by_name or name in API

    # ------------------------------------------------------ тип выражения
    def type_of(self, expr, scope, owner):
        e = expr.strip()
        if not e:
            return UNKNOWN
        while e.startswith('(') and e.endswith(')') and balance(e[1:-1]) == 0:
            e = e[1:-1].strip()
        if not e:
            return UNKNOWN
        if e.startswith('await '):
            return self.type_of(e[6:], scope, owner)
        i = find_top(e, [' as '])
        if i >= 0:
            t = e[i + 4:].strip()
            return t if re.match(r'^[\w\.\[\]]+$', t) else UNKNOWN
        i = find_top(e, [' if '])
        if i >= 0:
            rest = e[i + 4:]
            j = find_top(rest, [' else '])
            if j >= 0:
                a = self.type_of(e[:i], scope, owner)
                b = self.type_of(rest[j + 6:], scope, owner)
                if a == b:
                    return a
                return 'Variant' if 'Variant' in (a, b) else UNKNOWN
        i = find_top(e, [' or ', ' and '])
        if i >= 0:
            a = self.type_of(e[:i], scope, owner)
            b = self.type_of(e[i + 4:].strip() if e[i + 1] == 'n' else e[i + 5:], scope, owner)
            return 'bool' if a == 'bool' and b == 'bool' else UNKNOWN
        for op in ('==', '!=', '<=', '>=', '<', '>', ' in '):
            i = find_top(e, [op])
            if i >= 0:
                return 'bool'
        if e.startswith('not '):
            return 'bool'
        for op in (' + ', ' - ', ' * ', ' / ', ' % '):
            i = find_top(e, [op])
            if i >= 0:
                a = self.type_of(e[:i], scope, owner)
                b = self.type_of(e[i + len(op):], scope, owner)
                if a == 'Variant' or b == 'Variant':
                    return 'Variant'
                if op == ' + ' and (a == 'String' or b == 'String'):
                    return 'String'
                if op == ' % ' and (a == 'String' or b == 'String'):
                    return 'String'
                if a in NUMERIC and b in NUMERIC:
                    return 'float' if 'float' in (a, b) else 'int'
                if a == b and a != UNKNOWN:
                    return a
                if a in ('Vector2', 'Vector2i', 'Color', 'Vector3') and b in NUMERIC:
                    return a
                if b in ('Vector2', 'Vector2i', 'Color', 'Vector3') and a in NUMERIC:
                    return b
                return UNKNOWN
        if e.startswith(('-', '+')):
            return self.type_of(e[1:], scope, owner)
        lit = literal_type(e)
        if lit:
            return lit
        m_new = re.match(r'^([A-Z]\w*)\.new\s*\(', e)
        if m_new:
            cls = m_new.group(1)
            if cls in ('GDScript', 'Script', 'WeakRef'):
                return 'Variant' if cls != 'WeakRef' else 'WeakRef'
            if self.is_class(cls):
                return cls
            return UNKNOWN
        # индексация
        if e.endswith(']'):
            depth = 0
            for j in range(len(e) - 1, -1, -1):
                if e[j] == ']':
                    depth += 1
                elif e[j] == '[':
                    depth -= 1
                    if depth == 0:
                        base = e[:j].strip()
                        bt = self.type_of(base, scope, owner)
                        if bt == UNKNOWN:
                            bt = self.declared(base, scope, owner)
                        if bt and bt.startswith('Array['):
                            return bt[6:-1]
                        if bt in ('Array', 'Dictionary', 'Variant'):
                            return 'Variant'
                        if bt == 'String':
                            return 'String'
                        if bt in ('PackedStringArray',):
                            return 'String'
                        if bt in ('PackedByteArray',):
                            return 'int'
                        if bt in ('PackedVector2Array',):
                            return 'Vector2'
                        return UNKNOWN
        call = split_call(e)
        if call:
            receiver, fname, args = call
            if receiver is None:
                if fname in ('str', 'String'):
                    return 'String'
                if fname == 'float':
                    return 'float'
                if fname == 'int':
                    return 'int'
                if fname == 'bool':
                    return 'bool'
                if fname == 'len':
                    return 'int'
                f = self.func_of(owner.name, fname) if owner and owner.name else None
                if f is None and owner:
                    f = owner.funcs.get(fname)
                if f is None and owner:
                    f = self.func_of(owner.base or '', fname)
                if f is not None:
                    return f.ret
                if fname in GLOB_METHODS:
                    r = GLOB_METHODS[fname]
                    return r if r != 'Variant' else 'Variant'
                if self.is_class(fname):
                    return fname
                return UNKNOWN
            recv = receiver.strip()
            static_cls = recv if self.is_class(recv) else None
            k = self.by_name.get(static_cls) if static_cls else None
            if k is None and static_cls in self.autos:
                k = self.autos[static_cls]
            if static_cls and (k or static_cls in API):
                if k:
                    f = self.func_of(k.name, fname)
                    if f is not None:
                        return f.ret
                    if fname in VARIANT_RETURNERS:
                        return 'Variant'
                    return UNKNOWN
                # метод класса движка: FileAccess.open(), Time.get_ticks_msec(), OS.* …
                for c in self.chain(static_cls):
                    info = API.get(c)
                    if info and fname in info.get('methods', {}):
                        return info['methods'][fname]['return']
                return UNKNOWN
            rt = self.type_of(receiver, scope, owner)
            if rt == UNKNOWN:
                rt = self.declared(receiver, scope, owner)
            if rt == 'Variant':
                return 'Variant'
            if rt and rt.startswith('Array['):
                elem = rt[6:-1]
                if fname in ('pop_back', 'pop_front', 'pop_at', 'front', 'back', 'max', 'min',
                             'pick_random', 'reduce'):
                    return elem
                if fname in ('duplicate', 'slice', 'filter', 'map', 'keys', 'values'):
                    return rt
                if fname == 'size':
                    return 'int'
            if rt in ('Array', 'Dictionary'):
                if fname in VARIANT_RETURNERS:
                    return 'Variant'
                if fname in ('keys', 'values'):
                    return 'Array'
                if fname in ('size', 'count'):
                    return 'int'
                if fname in ('has', 'has_all', 'is_empty', 'erase', 'append', 'push_back',
                             'clear', 'merge', 'sort', 'shuffle', 'reverse', 'resize'):
                    return 'bool' if fname.startswith('has') or fname in ('is_empty',) else UNKNOWN
                return UNKNOWN
            if rt == 'String' and fname == 'split':
                return 'PackedStringArray'
            info = API.get(rt)
            k2 = self.by_name.get(rt)
            if k2:
                f = self.func_of(rt, fname)
                if f is not None:
                    return f.ret
                return UNKNOWN
            if info:
                m = info.get('methods', {}).get(fname)
                if m is not None:
                    if rt == 'Array' and fname in VARIANT_RETURNERS:
                        return 'Variant'
                    return m['return']
                return UNKNOWN
            return UNKNOWN
        i = find_top(e, ['.'])
        if i > 0:
            recv, attr = e[:i].strip(), e[i + 1:].strip()
            if not re.match(r'^[\w\.\[\]\"\']+$', recv):
                return UNKNOWN
            if recv in self.autos:
                k = self.autos[recv]
                return k.member_type(attr) or UNKNOWN
            if self.is_class(recv):
                t = self.member_of(recv, attr)
                return t if t else UNKNOWN
            rt = self.type_of(recv, scope, owner)
            if rt == UNKNOWN:
                rt = self.declared(recv, scope, owner)
            if rt in ('Dictionary', 'Variant', 'Array'):
                return 'Variant'
            if rt and rt != UNKNOWN:
                t = self.member_of(rt, attr)
                if t:
                    return t
            return UNKNOWN
        if re.match(r'^[A-Za-z_]\w*$', e):
            t = self.declared(e, scope, owner)
            if t:
                return t
            if e in self.autos:
                return e
            if self.is_class(e):
                return e
            if e in GLOB.get('constants', {}):
                return 'Variant'
            return UNKNOWN
        return UNKNOWN

    def declared(self, name, scope, owner):
        name = name.strip()
        if name in scope:
            return scope[name]
        if owner:
            t = owner.member_type(name)
            if t:
                return t
        if name in self.autos:
            return name
        return None


def split_call(e):
    if not e.endswith(')') or '(' not in e:
        return None
    depth = 0
    for j in range(len(e) - 1, -1, -1):
        c = e[j]
        if c == ')':
            depth += 1
        elif c == '(':
            depth -= 1
            if depth == 0:
                head = e[:j].strip()
                if not head:
                    return None
                m = re.match(r'^(.+?)\.([A-Za-z_]\w*)$', head, re.S)
                if m and not m.group(1).strip()[0] in '"\'':
                    return m.group(1).strip(), m.group(2), e[j + 1:-1]
                if re.match(r'^[A-Za-z_]\w*$', head):
                    return None, head, e[j + 1:-1]
                return None
    return None


# ============================================================= проверки
def check_inference(classes, files, res, problems):
    for k in files:
        scope = {}
        header_scope = {}
        in_func = None
        for start, text in k.lines:
            indent = len(text) - len(text.lstrip('\t'))
            s = text.strip()
            if not s or s.startswith('#'):
                continue
            if indent == 0:
                m = re.match(r'(?:static\s+)?func\s+(\w+)\s*\((.*?)\)', s, re.S)
                if m:
                    in_func = m.group(1)
                    scope = {n: t for n, t, _ in parse_params(m.group(2))}
                    continue
            m = re.match(r'var\s+([\w,\s]+?)\s*(?::\s*([\w\.\[\]]+))?\s*(:=|=)\s*(.*)$', s, re.S)
            if m:
                names = [n.strip() for n in m.group(1).split(',')]
                tpe, op, rhs = m.group(2), m.group(3), m.group(4).strip()
                if tpe:                     # var x: Тип = …
                    for n in names:
                        scope[n] = tpe
                    continue
                if op == '=':               # var x = … -> просто Variant, ошибки нет
                    for n in names:
                        scope[n] = 'Variant'
                    continue
                t = res.type_of(rhs, scope, k)          # var x := … -> тип обязан выводиться
                if t == 'Variant':
                    problems.append((k, start, s,
                                     'var %s := … — выражение имеет тип Variant, тип не выводится '
                                     '(Godot: "Cannot infer the type of \"%s\" variable"). '
                                     'Поставь явный тип: var %s: <тип> = …' % (names[0], names[0], names[0])))
                for n in names:
                    scope[n] = t if t != UNKNOWN else None
                continue
            m = re.match(r'for\s+(\w+)\s*(?::\s*([\w\.\[\]]+))?\s+in\s+(.*?):\s*$', s)
            if m:
                scope[m.group(1)] = m.group(2)
                continue
            m = re.match(r'(?:static\s+)?(?:@\w+(?:\([^)]*\))?\s*)*(var|const)\s+(\w+)\s*'
                         r'(?::\s*([\w\.\[\]]+))?\s*:?=\s*(.*)$', s)
            if m and indent > 0:
                t = m.group(3) or res.type_of(m.group(4).strip(), scope, k)
                scope[m.group(2)] = t if t != UNKNOWN else None


def check_names_and_signatures(classes, files, res, problems):
    base_api = API
    for k in files:
        decl = {}
        for start, text in k.lines:
            if text.startswith(('\t', ' ')):
                continue
            s = text.strip()
            m = re.match(r'(signal|var|const|enum|func|static\s+var|static\s+func)\s+([A-Za-z_]\w*)', s)
            if m:
                decl.setdefault(m.group(2), []).append((m.group(1).split()[-1], start, s))
        for name, occ in decl.items():
            if len(occ) > 1:
                kinds = ', '.join(sorted({o[0] for o in occ}))
                problems.append((k, occ[0][1], occ[0][2],
                                 'имя "%s" объявлено %d раза (%s) — Godot не разрешит такое'
                                 % (name, len(occ), kinds)))
        # перекрытие членов базового класса
        if k.base:
            for c in res.chain(k.base):
                info = base_api.get(c)
                if not info:
                    continue
                for name in decl:
                    if name.startswith('_'):
                        continue
                    if (name in info.get('members', {}) or name in info.get('constants', {})
                            or name in info.get('signals', {})):
                        problems.append((k, decl[name][0][1], decl[name][0][2],
                                         '"%s" перекрывает встроенный член класса %s' % (name, c)))
        # сигнатуры виртуальных методов
        if k.base:
            for fname, f in k.funcs.items():
                if not fname.startswith('_'):
                    continue
                for c in res.chain(k.base):
                    info = base_api.get(c)
                    if not info:
                        continue
                    m = info.get('methods', {}).get(fname)
                    if m is None:
                        continue
                    want = m['params']
                    got = [t for _, t, _ in f.params]
                    if len(got) != len(want) or any(
                            g != w and g != 'Variant' for g, w in zip(got, want)):
                        problems.append((k, f.line, 'func %s(%s)' % (fname, ', '.join(got)),
                                         '%s() из %s ожидает аргументы %s, а объявлено %s'
                                         % (fname, c, want or '[]', got or '[]')))
                    break
        # вызов нестатического метода через имя класса
        for fname, f in k.funcs.items():
            if fname in ('_ready', '_init'):
                continue
        for start, text in k.lines:
            s = text.strip()
            for m in re.finditer(r'\b([A-Z]\w*)\.(\w+)\s*\(', s):
                cls_name, meth = m.group(1), m.group(2)
                if cls_name in res.autos:
                    continue          # автозагрузка — это объект-синглтон, вызов законен
                if not (self_ := res.by_name.get(cls_name)):
                    continue
                kk = self_ or res.autos[cls_name]
                target = kk.funcs.get(meth)
                if target is not None and not target.static and not meth.startswith('_'):
                    problems.append((k, start, s,
                                     '%s.%s() — метод нестатический, вызов через имя класса '
                                     'не сработает' % (cls_name, meth)))


def check_types_and_misc(classes, files, res, problems):
    # неизвестные типы в аннотациях
    for k in files:
        local_enums = set(k.enums.keys())
        for m in re.finditer(r'^\t*(?:static\s+)?(?:var|const)\s+\w+\s*:\s*([\w\.\[\]]+)',
                             k.src, re.M):
            base = m.group(1).split('[')[0]
            if base in local_enums:
                continue
            if base not in BUILTIN_TYPES and not res.is_class(base):
                problems.append((k, k.src[:m.start()].count('\n') + 1, m.group(0).strip(),
                                 'неизвестный тип "%s" в объявлении' % base))
        for m in re.finditer(r'(?:func\s+\w+\s*\([^)]*\)\s*->\s*([\w\.\[\]]+))', k.src):
            base = m.group(1).split('[')[0]
            if base not in BUILTIN_TYPES and not res.is_class(base):
                problems.append((k, k.src[:m.start()].count('\n') + 1, m.group(0).strip(),
                                 'неизвестный тип "%s" в возвращаемом значении' % base))
        local_enums = set(k.enums.keys())
        for m in re.finditer(r'^\t*func\s+\w+\s*\((.*?)\)', k.src, re.M | re.S):
            for raw in top_split(m.group(1), ','):
                raw = raw.strip()
                if ':' not in raw:
                    continue
                tp = raw.split(':', 1)[1].split('=')[0].strip()
                base = tp.split('[')[0]
                if base in local_enums:
                    continue
                if base and base not in BUILTIN_TYPES and not res.is_class(base):
                    problems.append((k, k.src[:m.start()].count('\n') + 1, raw,
                                     'неизвестный тип "%s" в параметре' % base))
    # дубли class_name
    names = {}
    for k in files:
        if k.name:
            if k.name in names:
                problems.append((k, 1, 'class_name %s' % k.name,
                                 'класс с именем %s уже объявлен в %s' % (k.name, names[k.name].rel)))
            names[k.name] = k
            if k.name in API:
                problems.append((k, 1, 'class_name %s' % k.name,
                                 'класс %s перекрывает встроенный класс Godot' % k.name))
    # значения enum
    for k in files:
        for start, text in k.lines:
            for m in re.finditer(r'\b([A-Z]\w*)\.([A-Z][A-Z0-9_]*)\b', text):
                cls_name, val = m.group(1), m.group(2)
                kk = res.by_name.get(cls_name)
                if not kk:
                    continue
                if kk.enums and not any(val in vals for vals in kk.enums.values()):
                    if val not in kk.consts and val not in kk.static_vars:
                        problems.append((k, start, text.strip(),
                                         '%s.%s — такого значения нет в enum класса %s'
                                         % (cls_name, val, cls_name)))


def check_res_paths(problems):
    pattern = re.compile(r'res://([A-Za-z0-9_./-]+)')
    for folder, dirs, files in os.walk(ROOT):
        dirs[:] = [d for d in dirs if d not in ('.godot', '.git', 'build', 'export', 'tools')]
        for fname in files:
            if not fname.endswith(('.gd', '.tscn', '.tres', '.godot')):
                continue
            path = os.path.join(folder, fname)
            text = open(path, encoding='utf-8', errors='replace').read()
            for m in pattern.finditer(text):
                if not os.path.exists(os.path.join(ROOT, m.group(1).rstrip('.'))):
                    problems.append((path, text[:m.start()].count('\n') + 1, m.group(0),
                                     'путь никуда не ведёт'))


class FakeKlass:
    def __init__(self, path):
        self.rel = os.path.relpath(path, ROOT)
        self.src = open(path, encoding='utf-8').read() if os.path.exists(path) else ''


def resolve_member_inits(classes, files, res):
    """Типы членов вида 'var x := <expr>' — после того как разобраны все классы."""
    for k in files:
        for name, rhs in k.member_inits.items():
            t = res.type_of(rhs, {}, k)
            k.members[name] = t if t != UNKNOWN else 'Variant'


def main():
    classes, files = parse_project()
    res = Resolver(classes, autoloads(classes))
    resolve_member_inits(classes, files, res)
    problems = []
    check_inference(classes, files, res, problems)
    check_names_and_signatures(classes, files, res, problems)
    check_types_and_misc(classes, files, res, problems)
    check_res_paths(problems)

    print('Проверено файлов .gd: %d' % len(files))
    if not problems:
        print('Проблем не найдено — можно запускать в Godot (F5).')
        return 0
    print('Найдено проблем: %d\n' % len(problems))
    seen = set()
    for k, line, text, msg in problems:
        rel = k.rel if hasattr(k, 'rel') else str(k)
        if isinstance(rel, str) and rel.startswith(ROOT):
            rel = os.path.relpath(rel, ROOT)
        key = (rel, line, msg)
        if key in seen:
            continue
        seen.add(key)
        print('  • %s:%d' % (rel, line))
        print('      %s' % msg)
    return 1


if __name__ == '__main__':
    sys.exit(main())
